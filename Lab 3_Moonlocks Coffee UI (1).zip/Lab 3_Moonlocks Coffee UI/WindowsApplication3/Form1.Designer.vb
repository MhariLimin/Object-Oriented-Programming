﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.nameTB = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.addressTB = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cityTB = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.stateTB = New System.Windows.Forms.TextBox()
        Me.zipTB = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.regularTB = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.decafTB = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.tpoundsLabel = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.tpriceLabel = New System.Windows.Forms.TextBox()
        Me.calcuBtn = New System.Windows.Forms.Button()
        Me.printBtn = New System.Windows.Forms.Button()
        Me.clearBtn = New System.Windows.Forms.Button()
        Me.exitBtn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cooper Black", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(363, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(275, 49)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Order Form"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(104, 108)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Name:"
        '
        'nameTB
        '
        Me.nameTB.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nameTB.Location = New System.Drawing.Point(108, 144)
        Me.nameTB.Name = "nameTB"
        Me.nameTB.Size = New System.Drawing.Size(414, 34)
        Me.nameTB.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(104, 195)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(89, 23)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Address:"
        '
        'addressTB
        '
        Me.addressTB.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.addressTB.Location = New System.Drawing.Point(108, 232)
        Me.addressTB.Name = "addressTB"
        Me.addressTB.Size = New System.Drawing.Size(414, 34)
        Me.addressTB.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(104, 288)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(50, 23)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "City:"
        '
        'cityTB
        '
        Me.cityTB.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cityTB.Location = New System.Drawing.Point(108, 319)
        Me.cityTB.Name = "cityTB"
        Me.cityTB.Size = New System.Drawing.Size(414, 34)
        Me.cityTB.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(104, 383)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 23)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "State:"
        '
        'stateTB
        '
        Me.stateTB.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.stateTB.Location = New System.Drawing.Point(108, 415)
        Me.stateTB.Name = "stateTB"
        Me.stateTB.Size = New System.Drawing.Size(95, 34)
        Me.stateTB.TabIndex = 4
        '
        'zipTB
        '
        Me.zipTB.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.zipTB.Location = New System.Drawing.Point(222, 415)
        Me.zipTB.Name = "zipTB"
        Me.zipTB.Size = New System.Drawing.Size(95, 34)
        Me.zipTB.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(218, 383)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(43, 23)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Zip:"
        '
        'regularTB
        '
        Me.regularTB.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.regularTB.Location = New System.Drawing.Point(344, 415)
        Me.regularTB.Name = "regularTB"
        Me.regularTB.Size = New System.Drawing.Size(73, 34)
        Me.regularTB.TabIndex = 6
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(340, 383)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(84, 23)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Regular:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(438, 383)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(68, 23)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "Decaf:"
        '
        'decafTB
        '
        Me.decafTB.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.decafTB.Location = New System.Drawing.Point(442, 415)
        Me.decafTB.Name = "decafTB"
        Me.decafTB.Size = New System.Drawing.Size(73, 34)
        Me.decafTB.TabIndex = 7
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(108, 488)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(161, 23)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Pounds Ordered:"
        '
        'tpoundsLabel
        '
        Me.tpoundsLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tpoundsLabel.Location = New System.Drawing.Point(108, 520)
        Me.tpoundsLabel.Name = "tpoundsLabel"
        Me.tpoundsLabel.Size = New System.Drawing.Size(153, 34)
        Me.tpoundsLabel.TabIndex = 8
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(326, 488)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(109, 23)
        Me.Label10.TabIndex = 17
        Me.Label10.Text = "Total Price:"
        '
        'tpriceLabel
        '
        Me.tpriceLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tpriceLabel.Location = New System.Drawing.Point(330, 520)
        Me.tpriceLabel.Name = "tpriceLabel"
        Me.tpriceLabel.Size = New System.Drawing.Size(153, 34)
        Me.tpriceLabel.TabIndex = 9
        '
        'calcuBtn
        '
        Me.calcuBtn.Font = New System.Drawing.Font("Constantia", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.calcuBtn.Location = New System.Drawing.Point(668, 144)
        Me.calcuBtn.Name = "calcuBtn"
        Me.calcuBtn.Size = New System.Drawing.Size(234, 43)
        Me.calcuBtn.TabIndex = 10
        Me.calcuBtn.Text = "Calculate Order"
        Me.calcuBtn.UseVisualStyleBackColor = True
        '
        'printBtn
        '
        Me.printBtn.Font = New System.Drawing.Font("Constantia", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.printBtn.Location = New System.Drawing.Point(668, 232)
        Me.printBtn.Name = "printBtn"
        Me.printBtn.Size = New System.Drawing.Size(234, 43)
        Me.printBtn.TabIndex = 11
        Me.printBtn.Text = "Print Order"
        Me.printBtn.UseVisualStyleBackColor = True
        '
        'clearBtn
        '
        Me.clearBtn.Font = New System.Drawing.Font("Constantia", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.clearBtn.Location = New System.Drawing.Point(668, 319)
        Me.clearBtn.Name = "clearBtn"
        Me.clearBtn.Size = New System.Drawing.Size(234, 43)
        Me.clearBtn.TabIndex = 12
        Me.clearBtn.Text = "Clear Order"
        Me.clearBtn.UseVisualStyleBackColor = True
        '
        'exitBtn
        '
        Me.exitBtn.Font = New System.Drawing.Font("Constantia", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exitBtn.Location = New System.Drawing.Point(668, 406)
        Me.exitBtn.Name = "exitBtn"
        Me.exitBtn.Size = New System.Drawing.Size(234, 43)
        Me.exitBtn.TabIndex = 13
        Me.exitBtn.Text = "Exit"
        Me.exitBtn.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1018, 652)
        Me.Controls.Add(Me.exitBtn)
        Me.Controls.Add(Me.clearBtn)
        Me.Controls.Add(Me.printBtn)
        Me.Controls.Add(Me.calcuBtn)
        Me.Controls.Add(Me.tpriceLabel)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.tpoundsLabel)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.decafTB)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.regularTB)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.zipTB)
        Me.Controls.Add(Me.stateTB)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.cityTB)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.addressTB)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.nameTB)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Moonlocks Coffee"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents nameTB As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents addressTB As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cityTB As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents stateTB As System.Windows.Forms.TextBox
    Friend WithEvents zipTB As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents regularTB As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents decafTB As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents tpoundsLabel As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents tpriceLabel As System.Windows.Forms.TextBox
    Friend WithEvents calcuBtn As System.Windows.Forms.Button
    Friend WithEvents printBtn As System.Windows.Forms.Button
    Friend WithEvents clearBtn As System.Windows.Forms.Button
    Friend WithEvents exitBtn As System.Windows.Forms.Button

End Class
