﻿Public Class Form1

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles exitBtn.Click
        Me.Close()
    End Sub
End Class
