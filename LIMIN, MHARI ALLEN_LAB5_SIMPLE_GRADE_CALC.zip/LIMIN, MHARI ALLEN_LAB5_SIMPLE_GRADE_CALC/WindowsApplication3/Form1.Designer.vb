﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.translabel = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.CalcuBtn = New System.Windows.Forms.Button()
        Me.ClrBtn = New System.Windows.Forms.Button()
        Me.ExtBtn = New System.Windows.Forms.Button()
        Me.prelimlbl = New System.Windows.Forms.Label()
        Me.PRELIMTB = New System.Windows.Forms.TextBox()
        Me.Midtermlbl = New System.Windows.Forms.Label()
        Me.MIDTERMTB = New System.Windows.Forms.TextBox()
        Me.Finalslbl = New System.Windows.Forms.Label()
        Me.FINALSTB = New System.Windows.Forms.TextBox()
        Me.FGradelbl = New System.Windows.Forms.Label()
        Me.FGRADETB = New System.Windows.Forms.TextBox()
        Me.Transmutelbl = New System.Windows.Forms.Label()
        Me.TRANSMUTETB = New System.Windows.Forms.TextBox()
        Me.Rmrkslbl = New System.Windows.Forms.Label()
        Me.RMRKSTB = New System.Windows.Forms.TextBox()
        Me.inplbl = New System.Windows.Forms.Label()
        Me.otplbl = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'translabel
        '
        Me.translabel.AutoSize = True
        Me.translabel.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.translabel.Location = New System.Drawing.Point(48, 57)
        Me.translabel.Name = "translabel"
        Me.translabel.Size = New System.Drawing.Size(178, 24)
        Me.translabel.TabIndex = 0
        Me.translabel.Text = "Grade Transmutation:"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.WindowsApplication3.My.Resources.Resources.MicrosoftTeams_image
        Me.PictureBox1.Location = New System.Drawing.Point(52, 93)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(283, 426)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'CalcuBtn
        '
        Me.CalcuBtn.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.CalcuBtn.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CalcuBtn.Location = New System.Drawing.Point(410, 93)
        Me.CalcuBtn.Name = "CalcuBtn"
        Me.CalcuBtn.Size = New System.Drawing.Size(146, 40)
        Me.CalcuBtn.TabIndex = 4
        Me.CalcuBtn.Text = "&CALCULATE"
        Me.CalcuBtn.UseVisualStyleBackColor = False
        '
        'ClrBtn
        '
        Me.ClrBtn.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClrBtn.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClrBtn.Location = New System.Drawing.Point(571, 93)
        Me.ClrBtn.Name = "ClrBtn"
        Me.ClrBtn.Size = New System.Drawing.Size(146, 40)
        Me.ClrBtn.TabIndex = 5
        Me.ClrBtn.Text = "CLEA&R"
        Me.ClrBtn.UseVisualStyleBackColor = False
        '
        'ExtBtn
        '
        Me.ExtBtn.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ExtBtn.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExtBtn.Location = New System.Drawing.Point(732, 93)
        Me.ExtBtn.Name = "ExtBtn"
        Me.ExtBtn.Size = New System.Drawing.Size(146, 40)
        Me.ExtBtn.TabIndex = 6
        Me.ExtBtn.Text = "&EXIT"
        Me.ExtBtn.UseVisualStyleBackColor = False
        '
        'prelimlbl
        '
        Me.prelimlbl.AutoSize = True
        Me.prelimlbl.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.prelimlbl.Location = New System.Drawing.Point(375, 216)
        Me.prelimlbl.Name = "prelimlbl"
        Me.prelimlbl.Size = New System.Drawing.Size(161, 24)
        Me.prelimlbl.TabIndex = 5
        Me.prelimlbl.Text = "Enter Prelim Grade:"
        '
        'PRELIMTB
        '
        Me.PRELIMTB.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PRELIMTB.Location = New System.Drawing.Point(389, 249)
        Me.PRELIMTB.Name = "PRELIMTB"
        Me.PRELIMTB.Size = New System.Drawing.Size(181, 28)
        Me.PRELIMTB.TabIndex = 1
        '
        'Midtermlbl
        '
        Me.Midtermlbl.AutoSize = True
        Me.Midtermlbl.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Midtermlbl.Location = New System.Drawing.Point(375, 295)
        Me.Midtermlbl.Name = "Midtermlbl"
        Me.Midtermlbl.Size = New System.Drawing.Size(175, 24)
        Me.Midtermlbl.TabIndex = 7
        Me.Midtermlbl.Text = "Enter Midterm Grade:"
        '
        'MIDTERMTB
        '
        Me.MIDTERMTB.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MIDTERMTB.Location = New System.Drawing.Point(389, 331)
        Me.MIDTERMTB.Name = "MIDTERMTB"
        Me.MIDTERMTB.Size = New System.Drawing.Size(181, 28)
        Me.MIDTERMTB.TabIndex = 2
        '
        'Finalslbl
        '
        Me.Finalslbl.AutoSize = True
        Me.Finalslbl.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Finalslbl.Location = New System.Drawing.Point(375, 383)
        Me.Finalslbl.Name = "Finalslbl"
        Me.Finalslbl.Size = New System.Drawing.Size(159, 24)
        Me.Finalslbl.TabIndex = 9
        Me.Finalslbl.Text = "Enter Finals Grade:"
        '
        'FINALSTB
        '
        Me.FINALSTB.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FINALSTB.Location = New System.Drawing.Point(389, 419)
        Me.FINALSTB.Name = "FINALSTB"
        Me.FINALSTB.Size = New System.Drawing.Size(181, 28)
        Me.FINALSTB.TabIndex = 3
        '
        'FGradelbl
        '
        Me.FGradelbl.AutoSize = True
        Me.FGradelbl.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FGradelbl.Location = New System.Drawing.Point(666, 216)
        Me.FGradelbl.Name = "FGradelbl"
        Me.FGradelbl.Size = New System.Drawing.Size(147, 24)
        Me.FGradelbl.TabIndex = 11
        Me.FGradelbl.Text = "Total Final Grade:"
        '
        'FGRADETB
        '
        Me.FGRADETB.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FGRADETB.Location = New System.Drawing.Point(682, 249)
        Me.FGRADETB.Name = "FGRADETB"
        Me.FGRADETB.Size = New System.Drawing.Size(143, 39)
        Me.FGRADETB.TabIndex = 7
        '
        'Transmutelbl
        '
        Me.Transmutelbl.AutoSize = True
        Me.Transmutelbl.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Transmutelbl.Location = New System.Drawing.Point(666, 313)
        Me.Transmutelbl.Name = "Transmutelbl"
        Me.Transmutelbl.Size = New System.Drawing.Size(126, 24)
        Me.Transmutelbl.TabIndex = 13
        Me.Transmutelbl.Text = "Transmutation:"
        '
        'TRANSMUTETB
        '
        Me.TRANSMUTETB.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TRANSMUTETB.Location = New System.Drawing.Point(682, 350)
        Me.TRANSMUTETB.Name = "TRANSMUTETB"
        Me.TRANSMUTETB.Size = New System.Drawing.Size(143, 39)
        Me.TRANSMUTETB.TabIndex = 8
        '
        'Rmrkslbl
        '
        Me.Rmrkslbl.AutoSize = True
        Me.Rmrkslbl.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rmrkslbl.Location = New System.Drawing.Point(666, 419)
        Me.Rmrkslbl.Name = "Rmrkslbl"
        Me.Rmrkslbl.Size = New System.Drawing.Size(83, 24)
        Me.Rmrkslbl.TabIndex = 15
        Me.Rmrkslbl.Text = "Remarks:"
        '
        'RMRKSTB
        '
        Me.RMRKSTB.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RMRKSTB.Location = New System.Drawing.Point(682, 458)
        Me.RMRKSTB.Name = "RMRKSTB"
        Me.RMRKSTB.Size = New System.Drawing.Size(143, 39)
        Me.RMRKSTB.TabIndex = 9
        Me.RMRKSTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'inplbl
        '
        Me.inplbl.AutoSize = True
        Me.inplbl.Font = New System.Drawing.Font("Arial Black", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.inplbl.Location = New System.Drawing.Point(424, 176)
        Me.inplbl.Name = "inplbl"
        Me.inplbl.Size = New System.Drawing.Size(88, 28)
        Me.inplbl.TabIndex = 17
        Me.inplbl.Text = "INPUT:"
        '
        'otplbl
        '
        Me.otplbl.AutoSize = True
        Me.otplbl.Font = New System.Drawing.Font("Arial Black", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.otplbl.Location = New System.Drawing.Point(693, 176)
        Me.otplbl.Name = "otplbl"
        Me.otplbl.Size = New System.Drawing.Size(111, 28)
        Me.otplbl.TabIndex = 18
        Me.otplbl.Text = "OUTPUT:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.ClientSize = New System.Drawing.Size(933, 543)
        Me.Controls.Add(Me.otplbl)
        Me.Controls.Add(Me.inplbl)
        Me.Controls.Add(Me.RMRKSTB)
        Me.Controls.Add(Me.Rmrkslbl)
        Me.Controls.Add(Me.TRANSMUTETB)
        Me.Controls.Add(Me.Transmutelbl)
        Me.Controls.Add(Me.FGRADETB)
        Me.Controls.Add(Me.FGradelbl)
        Me.Controls.Add(Me.FINALSTB)
        Me.Controls.Add(Me.Finalslbl)
        Me.Controls.Add(Me.MIDTERMTB)
        Me.Controls.Add(Me.Midtermlbl)
        Me.Controls.Add(Me.PRELIMTB)
        Me.Controls.Add(Me.prelimlbl)
        Me.Controls.Add(Me.ExtBtn)
        Me.Controls.Add(Me.ClrBtn)
        Me.Controls.Add(Me.CalcuBtn)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.translabel)
        Me.Name = "Form1"
        Me.Text = "Simple Grade Calculator"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents translabel As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents CalcuBtn As System.Windows.Forms.Button
    Friend WithEvents ClrBtn As System.Windows.Forms.Button
    Friend WithEvents ExtBtn As System.Windows.Forms.Button
    Friend WithEvents prelimlbl As System.Windows.Forms.Label
    Friend WithEvents PRELIMTB As System.Windows.Forms.TextBox
    Friend WithEvents Midtermlbl As System.Windows.Forms.Label
    Friend WithEvents MIDTERMTB As System.Windows.Forms.TextBox
    Friend WithEvents Finalslbl As System.Windows.Forms.Label
    Friend WithEvents FINALSTB As System.Windows.Forms.TextBox
    Friend WithEvents FGradelbl As System.Windows.Forms.Label
    Friend WithEvents FGRADETB As System.Windows.Forms.TextBox
    Friend WithEvents Transmutelbl As System.Windows.Forms.Label
    Friend WithEvents TRANSMUTETB As System.Windows.Forms.TextBox
    Friend WithEvents Rmrkslbl As System.Windows.Forms.Label
    Friend WithEvents RMRKSTB As System.Windows.Forms.TextBox
    Friend WithEvents inplbl As System.Windows.Forms.Label
    Friend WithEvents otplbl As System.Windows.Forms.Label

End Class
