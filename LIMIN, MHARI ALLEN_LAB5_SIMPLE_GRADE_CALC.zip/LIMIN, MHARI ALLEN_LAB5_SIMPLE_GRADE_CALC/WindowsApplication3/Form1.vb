﻿Public Class Form1

    Private Sub CalcuBtn_Click(sender As Object, e As EventArgs) Handles CalcuBtn.Click
        FGRADETB.Text = ((PRELIMTB.Text * 0.3) + (MIDTERMTB.Text * 0.3) + (FINALSTB.Text * 0.4))
        If (FGRADETB.Text) >= 98 Then
            TRANSMUTETB.Text = "1.0"
            RMRKSTB.Text = "PASSED"

        ElseIf (FGRADETB.Text) >= 95 Then
            TRANSMUTETB.Text = "1.25"
            RMRKSTB.Text = "PASSED"

        ElseIf (FGRADETB.Text) >= 92 Then
            TRANSMUTETB.Text = "1.50"
            RMRKSTB.Text = "PASSED"

        ElseIf (FGRADETB.Text) >= 89 Then
            TRANSMUTETB.Text = "1.75"
            RMRKSTB.Text = "PASSED"

        ElseIf (FGRADETB.Text) >= 86 Then
            TRANSMUTETB.Text = "2.00"
            RMRKSTB.Text = "PASSED"

        ElseIf (FGRADETB.Text) >= 83 Then
            TRANSMUTETB.Text = "2.25"
            RMRKSTB.Text = "PASSED"

        ElseIf (FGRADETB.Text) >= 80 Then
            TRANSMUTETB.Text = "2.50"
            RMRKSTB.Text = "PASSED"

        ElseIf (FGRADETB.Text) >= 77 Then
            TRANSMUTETB.Text = "2.75"
            RMRKSTB.Text = "PASSED"

        ElseIf (FGRADETB.Text) >= 75 Then
            TRANSMUTETB.Text = "3.00"
            RMRKSTB.Text = "PASSED"

        Else
            TRANSMUTETB.Text = "5.00"
            RMRKSTB.Text = "FAILED"

        End If
    End Sub

    Private Sub ClrBtn_Click(sender As Object, e As EventArgs) Handles ClrBtn.Click
        For Each Control As Control In Me.Controls
            If TypeOf Control Is TextBox Then
                Control.Text = String.Empty
            End If
        Next
    End Sub

    Private Sub ExtBtn_Click(sender As Object, e As EventArgs) Handles ExtBtn.Click
        Me.Close()
    End Sub
End Class
