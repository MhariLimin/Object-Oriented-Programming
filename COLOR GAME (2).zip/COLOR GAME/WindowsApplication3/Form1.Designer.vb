﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ColorForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ColorForm))
        Me.ColorLabel = New System.Windows.Forms.Label()
        Me.Redbtn = New System.Windows.Forms.Button()
        Me.Purplebtn = New System.Windows.Forms.Button()
        Me.Yellowbtn = New System.Windows.Forms.Button()
        Me.Graybtn = New System.Windows.Forms.Button()
        Me.Brownbtn = New System.Windows.Forms.Button()
        Me.Bluebtn = New System.Windows.Forms.Button()
        Me.Orangebtn = New System.Windows.Forms.Button()
        Me.Pinkbtn = New System.Windows.Forms.Button()
        Me.Greenbtn = New System.Windows.Forms.Button()
        Me.Reset = New System.Windows.Forms.Button()
        Me.Print = New System.Windows.Forms.Button()
        Me.Textfont = New System.Windows.Forms.Button()
        Me.Ext = New System.Windows.Forms.Button()
        Me.PrintForm = New Microsoft.VisualBasic.PowerPacks.Printing.PrintForm(Me.components)
        Me.FontDialog = New System.Windows.Forms.FontDialog()
        Me.SuspendLayout()
        '
        'ColorLabel
        '
        Me.ColorLabel.AutoSize = True
        Me.ColorLabel.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ColorLabel.Location = New System.Drawing.Point(39, 59)
        Me.ColorLabel.Name = "ColorLabel"
        Me.ColorLabel.Size = New System.Drawing.Size(213, 30)
        Me.ColorLabel.TabIndex = 0
        Me.ColorLabel.Text = "Click a Color Button:"
        '
        'Redbtn
        '
        Me.Redbtn.Font = New System.Drawing.Font("Arial Narrow", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Redbtn.Location = New System.Drawing.Point(73, 117)
        Me.Redbtn.Name = "Redbtn"
        Me.Redbtn.Size = New System.Drawing.Size(160, 96)
        Me.Redbtn.TabIndex = 1
        Me.Redbtn.Text = "&Red"
        Me.Redbtn.UseVisualStyleBackColor = True
        '
        'Purplebtn
        '
        Me.Purplebtn.Font = New System.Drawing.Font("Arial Narrow", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Purplebtn.Location = New System.Drawing.Point(73, 358)
        Me.Purplebtn.Name = "Purplebtn"
        Me.Purplebtn.Size = New System.Drawing.Size(160, 96)
        Me.Purplebtn.TabIndex = 7
        Me.Purplebtn.Text = "P&urple"
        Me.Purplebtn.UseVisualStyleBackColor = True
        '
        'Yellowbtn
        '
        Me.Yellowbtn.Font = New System.Drawing.Font("Arial Narrow", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Yellowbtn.Location = New System.Drawing.Point(73, 238)
        Me.Yellowbtn.Name = "Yellowbtn"
        Me.Yellowbtn.Size = New System.Drawing.Size(160, 96)
        Me.Yellowbtn.TabIndex = 4
        Me.Yellowbtn.Text = "&Yellow"
        Me.Yellowbtn.UseVisualStyleBackColor = True
        '
        'Graybtn
        '
        Me.Graybtn.Font = New System.Drawing.Font("Arial Narrow", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Graybtn.Location = New System.Drawing.Point(255, 358)
        Me.Graybtn.Name = "Graybtn"
        Me.Graybtn.Size = New System.Drawing.Size(160, 96)
        Me.Graybtn.TabIndex = 8
        Me.Graybtn.Text = "&Gray"
        Me.Graybtn.UseVisualStyleBackColor = True
        '
        'Brownbtn
        '
        Me.Brownbtn.Font = New System.Drawing.Font("Arial Narrow", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Brownbtn.Location = New System.Drawing.Point(255, 238)
        Me.Brownbtn.Name = "Brownbtn"
        Me.Brownbtn.Size = New System.Drawing.Size(160, 96)
        Me.Brownbtn.TabIndex = 5
        Me.Brownbtn.Text = "Bro&wn"
        Me.Brownbtn.UseVisualStyleBackColor = True
        '
        'Bluebtn
        '
        Me.Bluebtn.Font = New System.Drawing.Font("Arial Narrow", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bluebtn.Location = New System.Drawing.Point(255, 117)
        Me.Bluebtn.Name = "Bluebtn"
        Me.Bluebtn.Size = New System.Drawing.Size(160, 96)
        Me.Bluebtn.TabIndex = 2
        Me.Bluebtn.Text = "&Blue"
        Me.Bluebtn.UseVisualStyleBackColor = True
        '
        'Orangebtn
        '
        Me.Orangebtn.Font = New System.Drawing.Font("Arial Narrow", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Orangebtn.Location = New System.Drawing.Point(438, 358)
        Me.Orangebtn.Name = "Orangebtn"
        Me.Orangebtn.Size = New System.Drawing.Size(160, 96)
        Me.Orangebtn.TabIndex = 9
        Me.Orangebtn.Text = "&Orange"
        Me.Orangebtn.UseVisualStyleBackColor = True
        '
        'Pinkbtn
        '
        Me.Pinkbtn.Font = New System.Drawing.Font("Arial Narrow", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pinkbtn.Location = New System.Drawing.Point(438, 238)
        Me.Pinkbtn.Name = "Pinkbtn"
        Me.Pinkbtn.Size = New System.Drawing.Size(160, 96)
        Me.Pinkbtn.TabIndex = 6
        Me.Pinkbtn.Text = "&Pink"
        Me.Pinkbtn.UseVisualStyleBackColor = True
        '
        'Greenbtn
        '
        Me.Greenbtn.Font = New System.Drawing.Font("Arial Narrow", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Greenbtn.Location = New System.Drawing.Point(438, 117)
        Me.Greenbtn.Name = "Greenbtn"
        Me.Greenbtn.Size = New System.Drawing.Size(160, 96)
        Me.Greenbtn.TabIndex = 3
        Me.Greenbtn.Text = "Gree&n"
        Me.Greenbtn.UseVisualStyleBackColor = True
        '
        'Reset
        '
        Me.Reset.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Reset.Location = New System.Drawing.Point(44, 487)
        Me.Reset.Name = "Reset"
        Me.Reset.Size = New System.Drawing.Size(160, 36)
        Me.Reset.TabIndex = 10
        Me.Reset.Text = "&Start Over"
        Me.Reset.UseVisualStyleBackColor = True
        '
        'Print
        '
        Me.Print.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Print.Location = New System.Drawing.Point(233, 487)
        Me.Print.Name = "Print"
        Me.Print.Size = New System.Drawing.Size(94, 36)
        Me.Print.TabIndex = 11
        Me.Print.Text = "&Print"
        Me.Print.UseVisualStyleBackColor = True
        '
        'Textfont
        '
        Me.Textfont.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textfont.Location = New System.Drawing.Point(356, 487)
        Me.Textfont.Name = "Textfont"
        Me.Textfont.Size = New System.Drawing.Size(94, 36)
        Me.Textfont.TabIndex = 12
        Me.Textfont.Text = "&Font"
        Me.Textfont.UseVisualStyleBackColor = True
        '
        'Ext
        '
        Me.Ext.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Ext.Location = New System.Drawing.Point(482, 487)
        Me.Ext.Name = "Ext"
        Me.Ext.Size = New System.Drawing.Size(94, 36)
        Me.Ext.TabIndex = 13
        Me.Ext.Text = "&Exit"
        Me.Ext.UseVisualStyleBackColor = True
        '
        'PrintForm
        '
        Me.PrintForm.DocumentName = "document"
        Me.PrintForm.Form = Me
        Me.PrintForm.PrintAction = System.Drawing.Printing.PrintAction.PrintToPrinter
        Me.PrintForm.PrinterSettings = CType(resources.GetObject("PrintForm.PrinterSettings"), System.Drawing.Printing.PrinterSettings)
        Me.PrintForm.PrintFileName = Nothing
        '
        'ColorForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(663, 559)
        Me.Controls.Add(Me.Ext)
        Me.Controls.Add(Me.Textfont)
        Me.Controls.Add(Me.Print)
        Me.Controls.Add(Me.Reset)
        Me.Controls.Add(Me.Greenbtn)
        Me.Controls.Add(Me.Pinkbtn)
        Me.Controls.Add(Me.Orangebtn)
        Me.Controls.Add(Me.Bluebtn)
        Me.Controls.Add(Me.Brownbtn)
        Me.Controls.Add(Me.Graybtn)
        Me.Controls.Add(Me.Yellowbtn)
        Me.Controls.Add(Me.Purplebtn)
        Me.Controls.Add(Me.Redbtn)
        Me.Controls.Add(Me.ColorLabel)
        Me.Name = "ColorForm"
        Me.Text = "Color Game"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ColorLabel As System.Windows.Forms.Label
    Friend WithEvents Redbtn As System.Windows.Forms.Button
    Friend WithEvents Purplebtn As System.Windows.Forms.Button
    Friend WithEvents Yellowbtn As System.Windows.Forms.Button
    Friend WithEvents Graybtn As System.Windows.Forms.Button
    Friend WithEvents Brownbtn As System.Windows.Forms.Button
    Friend WithEvents Bluebtn As System.Windows.Forms.Button
    Friend WithEvents Orangebtn As System.Windows.Forms.Button
    Friend WithEvents Pinkbtn As System.Windows.Forms.Button
    Friend WithEvents Greenbtn As System.Windows.Forms.Button
    Friend WithEvents Reset As System.Windows.Forms.Button
    Friend WithEvents Print As System.Windows.Forms.Button
    Friend WithEvents Textfont As System.Windows.Forms.Button
    Friend WithEvents Ext As System.Windows.Forms.Button
    Friend WithEvents PrintForm As Microsoft.VisualBasic.PowerPacks.Printing.PrintForm
    Friend WithEvents FontDialog As System.Windows.Forms.FontDialog

End Class
