﻿Public Class ColorForm

    Private Sub Redbtn_Click(sender As Object, e As EventArgs) Handles Redbtn.Click
        Redbtn.BackColor = Color.Red
    End Sub

    Private Sub Yellowbtn_Click(sender As Object, e As EventArgs) Handles Yellowbtn.Click
        Yellowbtn.BackColor = Color.Yellow
    End Sub

    Private Sub Purplebtn_Click(sender As Object, e As EventArgs) Handles Purplebtn.Click
        Purplebtn.BackColor = Color.Purple
    End Sub

    Private Sub Bluebtn_Click(sender As Object, e As EventArgs) Handles Bluebtn.Click
        Bluebtn.BackColor = Color.Blue
    End Sub

    Private Sub Brownbtn_Click(sender As Object, e As EventArgs) Handles Brownbtn.Click
        Brownbtn.BackColor = Color.Brown
    End Sub

    Private Sub Graybtn_Click(sender As Object, e As EventArgs) Handles Graybtn.Click
        Graybtn.BackColor = Color.Gray
    End Sub

    Private Sub Greenbtn_Click(sender As Object, e As EventArgs) Handles Greenbtn.Click
        Greenbtn.BackColor = Color.Green
    End Sub

    Private Sub Pinkbtn_Click(sender As Object, e As EventArgs) Handles Pinkbtn.Click
        Pinkbtn.BackColor = Color.Pink
    End Sub

    Private Sub Orangebtn_Click(sender As Object, e As EventArgs) Handles Orangebtn.Click
        Orangebtn.BackColor = Color.Orange
    End Sub

    Private Sub Reset_Click(sender As Object, e As EventArgs) Handles Reset.Click
        Redbtn.BackColor = Color.FromKnownColor(KnownColor.Control)
        Bluebtn.BackColor = Color.FromKnownColor(KnownColor.Control)
        Greenbtn.BackColor = Color.FromKnownColor(KnownColor.Control)
        Yellowbtn.BackColor = Color.FromKnownColor(KnownColor.Control)
        Brownbtn.BackColor = Color.FromKnownColor(KnownColor.Control)
        Pinkbtn.BackColor = Color.FromKnownColor(KnownColor.Control)
        Purplebtn.BackColor = Color.FromKnownColor(KnownColor.Control)
        Graybtn.BackColor = Color.FromKnownColor(KnownColor.Control)
        Orangebtn.BackColor = Color.FromKnownColor(KnownColor.Control)
    End Sub

    Private Sub Print_Click(sender As Object, e As EventArgs) Handles Print.Click
        PrintForm.PrintAction = Printing.PrintAction.PrintToPreview
        PrintForm.Print()
    End Sub

    Private Sub Font_Click(sender As Object, e As EventArgs) Handles Textfont.Click
        FontDialog.Font = Redbtn.Font
        FontDialog.Font = Bluebtn.Font
        FontDialog.Font = Greenbtn.Font
        FontDialog.Font = Yellowbtn.Font
        FontDialog.Font = Brownbtn.Font
        FontDialog.Font = Pinkbtn.Font
        FontDialog.Font = Purplebtn.Font
        FontDialog.Font = Graybtn.Font
        FontDialog.Font = Orangebtn.Font
        FontDialog.ShowDialog()
        Redbtn.Font = FontDialog.Font
        Bluebtn.Font = FontDialog.Font
        Greenbtn.Font = FontDialog.Font
        Yellowbtn.Font = FontDialog.Font
        Brownbtn.Font = FontDialog.Font
        Pinkbtn.Font = FontDialog.Font
        Purplebtn.Font = FontDialog.Font
        Graybtn.Font = FontDialog.Font
        Orangebtn.Font = FontDialog.Font
    End Sub

    Private Sub Close_Click(sender As Object, e As EventArgs) Handles Ext.Click
        Me.Close()
    End Sub
End Class
