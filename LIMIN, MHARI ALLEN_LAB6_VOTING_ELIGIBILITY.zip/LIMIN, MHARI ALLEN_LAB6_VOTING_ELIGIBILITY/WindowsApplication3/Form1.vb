﻿Public Class Form1
    Dim input As Integer
    Private Sub SUBMITBTN_Click(sender As Object, e As EventArgs) Handles SUBMITBTN.Click
        input = AgeTB.Text

        If (input >= 18) Then
            MsgBox("You are eligible to vote.")
        Else
            MsgBox("Sorry, you are still too young to vote")
        End If
    End Sub

    Private Sub AgeTB_KeyPress(sender As Object, e As KeyPressEventArgs) Handles AgeTB.KeyPress
        If Not Char.IsNumber(e.KeyChar) And Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) And Not e.KeyChar = Chr(Keys.Space) Then
            e.Handled = True
            MsgBox("Error, Please enter integer values only")
        End If
    End Sub

    Private Sub CLEARBTN_Click(sender As Object, e As EventArgs) Handles CLEARBTN.Click
        For Each Control As Control In Me.Controls
            If TypeOf Control Is TextBox Then
                Control.Text = String.Empty
            End If
        Next
    End Sub

    Private Sub EXTBTN_Click(sender As Object, e As EventArgs) Handles EXTBTN.Click
        Me.Close()
    End Sub
End Class
