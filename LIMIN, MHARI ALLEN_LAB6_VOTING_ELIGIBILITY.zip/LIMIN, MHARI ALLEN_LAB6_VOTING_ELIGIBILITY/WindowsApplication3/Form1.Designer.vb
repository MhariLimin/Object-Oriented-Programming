﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.AgeLbl = New System.Windows.Forms.Label()
        Me.AgeTB = New System.Windows.Forms.TextBox()
        Me.SUBMITBTN = New System.Windows.Forms.Button()
        Me.CLEARBTN = New System.Windows.Forms.Button()
        Me.EXTBTN = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'AgeLbl
        '
        Me.AgeLbl.AutoSize = True
        Me.AgeLbl.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AgeLbl.Location = New System.Drawing.Point(30, 36)
        Me.AgeLbl.Name = "AgeLbl"
        Me.AgeLbl.Size = New System.Drawing.Size(132, 29)
        Me.AgeLbl.TabIndex = 0
        Me.AgeLbl.Text = "Enter Age:"
        '
        'AgeTB
        '
        Me.AgeTB.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AgeTB.Location = New System.Drawing.Point(167, 35)
        Me.AgeTB.Name = "AgeTB"
        Me.AgeTB.Size = New System.Drawing.Size(100, 39)
        Me.AgeTB.TabIndex = 1
        Me.AgeTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'SUBMITBTN
        '
        Me.SUBMITBTN.BackColor = System.Drawing.Color.MediumAquamarine
        Me.SUBMITBTN.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SUBMITBTN.ForeColor = System.Drawing.Color.White
        Me.SUBMITBTN.Location = New System.Drawing.Point(12, 110)
        Me.SUBMITBTN.Name = "SUBMITBTN"
        Me.SUBMITBTN.Size = New System.Drawing.Size(100, 31)
        Me.SUBMITBTN.TabIndex = 2
        Me.SUBMITBTN.Text = "SUBMIT"
        Me.SUBMITBTN.UseVisualStyleBackColor = False
        '
        'CLEARBTN
        '
        Me.CLEARBTN.BackColor = System.Drawing.Color.MediumAquamarine
        Me.CLEARBTN.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CLEARBTN.ForeColor = System.Drawing.Color.White
        Me.CLEARBTN.Location = New System.Drawing.Point(118, 110)
        Me.CLEARBTN.Name = "CLEARBTN"
        Me.CLEARBTN.Size = New System.Drawing.Size(100, 31)
        Me.CLEARBTN.TabIndex = 3
        Me.CLEARBTN.Text = "CLEAR"
        Me.CLEARBTN.UseVisualStyleBackColor = False
        '
        'EXTBTN
        '
        Me.EXTBTN.BackColor = System.Drawing.Color.MediumAquamarine
        Me.EXTBTN.Font = New System.Drawing.Font("Arial", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EXTBTN.ForeColor = System.Drawing.Color.White
        Me.EXTBTN.Location = New System.Drawing.Point(224, 110)
        Me.EXTBTN.Name = "EXTBTN"
        Me.EXTBTN.Size = New System.Drawing.Size(100, 31)
        Me.EXTBTN.TabIndex = 4
        Me.EXTBTN.Text = "EXIT"
        Me.EXTBTN.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Lavender
        Me.ClientSize = New System.Drawing.Size(333, 153)
        Me.Controls.Add(Me.EXTBTN)
        Me.Controls.Add(Me.CLEARBTN)
        Me.Controls.Add(Me.SUBMITBTN)
        Me.Controls.Add(Me.AgeTB)
        Me.Controls.Add(Me.AgeLbl)
        Me.Name = "Form1"
        Me.Text = "Voting Eligibility "
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents AgeLbl As System.Windows.Forms.Label
    Friend WithEvents AgeTB As System.Windows.Forms.TextBox
    Friend WithEvents SUBMITBTN As System.Windows.Forms.Button
    Friend WithEvents CLEARBTN As System.Windows.Forms.Button
    Friend WithEvents EXTBTN As System.Windows.Forms.Button

End Class
